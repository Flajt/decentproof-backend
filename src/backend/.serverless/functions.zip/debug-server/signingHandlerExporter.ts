import { handler } from "../functions/sign";

export default handler;