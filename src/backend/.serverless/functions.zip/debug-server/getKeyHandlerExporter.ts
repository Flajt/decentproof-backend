import { handler } from "../functions/getNewKey";

export default handler;